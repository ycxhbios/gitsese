//
//  weatherModel.h
//  weatherDemo
//
//  Created by 杨晨曦 on 16/1/6.
//  Copyright © 2016年 杨晨曦. All rights reserved.
//z

#import <Foundation/Foundation.h>
@interface weatherModel : JSONModel

@property (nonatomic,strong)NSArray * HeWeather;



@end








