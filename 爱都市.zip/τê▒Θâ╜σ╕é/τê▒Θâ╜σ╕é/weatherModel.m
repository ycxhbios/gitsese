//
//  weatherModel.m
//  weatherDemo
//
//  Created by 杨晨曦 on 16/1/6.
//  Copyright © 2016年 杨晨曦. All rights reserved.
//

#import "weatherModel.h"

@implementation weatherModel

+(JSONKeyMapper *)keyMapper{
    
    JSONKeyMapper * mapper = [[JSONKeyMapper alloc]initWithJSONToModelBlock:^NSString *(NSString *keyName) {
        if ([keyName isEqualToString:@"HeWeather data service 3.0"]) {
            return @"HeWeather";
        }else{
            
            return keyName;
        }
    } modelToJSONBlock:^NSString *(NSString *keyName) {
        if ([keyName isEqualToString:@"HeWeather"]) {
            return @"HeWeather data service 3.0";
        }else{
            return keyName;
        }
    }];
    return mapper;
    
}



@end

