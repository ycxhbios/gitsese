//
//  weatherCell.m
//  爱都市
//
//  Created by 杨晨曦 on 16/1/14.
//  Copyright © 2016年 杨晨曦. All rights reserved.
//

#import "weatherCell.h"

@implementation weatherCell

- (void)awakeFromNib {
    
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
