#import "SearchViewController.h"
#import "KJAreaPickerView.h"
#import "KJLocation.h"
@interface SearchViewController ()<UITextFieldDelegate,KJAreaPickerViewDelegate>
@property (weak, nonatomic) IBOutlet UITextField *textField;
@property (nonatomic, strong) KJAreaPickerView *areaPickerView;
@end

@implementation SearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.textField.delegate = self;
    
}

-(void)cancelLocatePicker
{
    [self.areaPickerView cancelPicker];
    self.areaPickerView.delegate = nil;
    self.areaPickerView = nil;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [super touchesBegan:touches withEvent:event];
    // 取消areaPickerView
    [self cancelLocatePicker];
}
#pragma mark - UITextFieldDelegate的代理

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    // 1, 先清空AreaPickerView
    [self cancelLocatePicker];
    // 2，再初始化AreaPickerView
    self.areaPickerView = [KJAreaPickerView areaPickerViewWithDelegate:self];
    // 3，显示
    [self.areaPickerView showInView:self.view];
    return NO;
}
#pragma mark - KJAreaPickerViewDelegate的代理
- (void)pickerDidChangeStatus:(KJAreaPickerView *)picker
{
    self.textField.text = [NSString stringWithFormat:@"%@",picker.locate.city];
}
- (IBAction)buttonClicked:(UIButton *)sender {
    
    if(self.refreshLabelOfSuperView){
        self.refreshLabelOfSuperView(self.textField.text);
    }
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end



