//
//  MulticolorView.h
//  BasketBallDemo
//
//  Created by 杨晨曦 on 16/1/10.
//  Copyright © 2016年 杨晨曦. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MulticolorView : UIView
@property (nonatomic, assign) CGFloat          lineWidth;  // 圆的线宽
@property (nonatomic, assign) CFTimeInterval   sec;        // 秒
@property (nonatomic, assign) CGFloat          percent;    // 百分比

@property (nonatomic, strong) NSArray         *colors;     // 颜色组(CGColor)

- (void)startAnimation;
- (void)endAnimation;
@end
