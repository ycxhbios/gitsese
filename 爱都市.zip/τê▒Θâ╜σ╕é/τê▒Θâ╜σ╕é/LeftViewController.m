//
//  LeftViewController.m
//  爱都市
//
//  Created by 杨晨曦 on 16/1/14.
//  Copyright © 2016年 杨晨曦. All rights reserved.
//

#import "LeftViewController.h"
#import "YALSunnyRefreshControl.h"

@interface LeftViewController ()

@property (nonatomic,strong) YALSunnyRefreshControl *sunnyRefreshControl;
@property (weak, nonatomic) IBOutlet UIImageView *nowImageView;
@property (weak, nonatomic) IBOutlet UIImageView *todayImageView;
@property (weak, nonatomic) IBOutlet UIImageView *tomorrowImageView;

@end

@implementation LeftViewController

# pragma mark - UIView life cycle

- (void)viewDidLoad {
    
    [super viewDidLoad];
    [self setupRefreshControl];
    NSString *httpUrl = [NSString stringWithFormat:@"https://api.heweather.com/x3/weather?city=%@&key=cd90cdd6a5684cacaa16a87ce46f7097",self.city ];
    [self request:httpUrl];
    self.navigationController.navigationBar.hidden = NO;

}
-(void)request: (NSString*)httpUrl {
    [SVProgressHUD showWithStatus:@"正在加载..."];
    
    AFHTTPSessionManager *mgr = [AFHTTPSessionManager manager];
    [mgr GET:httpUrl parameters:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
        [SVProgressHUD dismiss];
        NSArray *arr = responseObject[@"HeWeather data service 3.0"];
        
        for (NSDictionary * dict in arr) {
            
            Model * model = [[Model alloc]initWithDictionary:dict error:nil];
            dispatch_async(dispatch_get_main_queue(), ^{
                NSLog(@"%@",model.now.cond.txt);
                
                if ([model.now.cond.txt isEqualToString:@"晴"]) {
                    self.nowImageView.image = [UIImage imageNamed:@"28X28-qing_bai"];
                    self.todayImageView.image= [UIImage imageNamed:@"28X28-qing_bai"];
                    self.tomorrowImageView.image =[UIImage imageNamed:@"28X28-duoyun_bai"];
                }
                if ([model.now.cond.txt isEqualToString:@"霾"]) {
                    self.nowImageView.image = [UIImage imageNamed:@"28X28-duoyun_bai"];
                    self.todayImageView.image= [UIImage imageNamed:@"28X28-duoyun_bai"];                    self.tomorrowImageView.image =[UIImage imageNamed:@"28X28-duoyun_bai"];


                }
                if ([model.now.cond.txt isEqualToString:@"阴"]) {
                    self.nowImageView.image = [UIImage imageNamed:@"28X28-yintian"];                    self.todayImageView.image= [UIImage imageNamed:@"28X28-yintian"];                    self.tomorrowImageView.image =[UIImage imageNamed:@"28X28-duoyun_bai"];


                }
                if ([model.now.cond.txt isEqualToString:@"小雨"]) {
                    self.nowImageView.image = [UIImage imageNamed:@"28X28-xiaoyu"];                    self.todayImageView.image= [UIImage imageNamed:@"28X28-xiaoyu"];                    self.tomorrowImageView.image =[UIImage imageNamed:@"28X28-zhongyu"];


                }
                if ([model.now.cond.txt isEqualToString:@"中雨"]) {
                    self.nowImageView.image = [UIImage imageNamed:@"28X28-zhongyu"];                    self.todayImageView.image= [UIImage imageNamed:@"28X28-zhongyu"];                    self.tomorrowImageView.image =[UIImage imageNamed:@"28X28-xiaoyu"];


                }
                if ([model.now.cond.txt isEqualToString:@"阵雨"]) {
                    self.nowImageView.image = [UIImage imageNamed:@"28X28-zhongyu"];                    self.todayImageView.image= [UIImage imageNamed:@"28X28-zhongyu"];                    self.tomorrowImageView.image =[UIImage imageNamed:@"28X28-xiaoyu"];
                    
                    
                }

                if ([model.now.cond.txt isEqualToString:@"大雨"]) {
                    self.nowImageView.image = [UIImage imageNamed:@"28X28-dayu"];                    self.todayImageView.image= [UIImage imageNamed:@"28X28-dayu"];                    self.tomorrowImageView.image =[UIImage imageNamed:@"28X28-duoyun_bai"];


                }
                if ([model.now.cond.txt isEqualToString:@"暴雨"]) {
                    self.nowImageView.image = [UIImage imageNamed:@"28X28-baoyu"];                    self.todayImageView.image= [UIImage imageNamed:@"28X28-baoyu"];                    self.tomorrowImageView.image =[UIImage imageNamed:@"28X28-dayu"];


                }
                if ([model.now.cond.txt isEqualToString:@"小雪"]) {
                    self.nowImageView.image = [UIImage imageNamed:@"28X28-zhongxue"];                    self.todayImageView.image= [UIImage imageNamed:@"28X28-zhongxue"];                    self.tomorrowImageView.image =[UIImage imageNamed:@"28X28-baoxue"];


                }
                if ([model.now.cond.txt isEqualToString:@"中雪"]) {
                    self.nowImageView.image = [UIImage imageNamed:@"28X28-zhongxue"];                    self.todayImageView.image= [UIImage imageNamed:@"28X28-zhongxue"];                    self.tomorrowImageView.image =[UIImage imageNamed:@"28X28-duoyun_bai"];


                }
                if ([model.now.cond.txt isEqualToString:@"大雪"]) {
                    self.nowImageView.image = [UIImage imageNamed:@"28X28-baoxue"];                    self.todayImageView.image= [UIImage imageNamed:@"28X28-baoxue"];                    self.tomorrowImageView.image =[UIImage imageNamed:@"28X28-dongyu"];


                }
                if ([model.now.cond.txt isEqualToString:@"多云"]) {
                    self.nowImageView.image = [UIImage imageNamed:@"28X28-dongyu"];                    self.todayImageView.image= [UIImage imageNamed:@"28X28-dongyu"];                    self.tomorrowImageView.image =[UIImage imageNamed:@"28X28-baoxue"];


                }
                for (NSDictionary * dict in model.daily_forecast) {
                    Daily_Forecast * model = [[Daily_Forecast alloc]initWithDictionary:dict error:nil];
                
                }
            });
        }
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        [SVProgressHUD showErrorWithStatus:[error localizedDescription]];
        
    }];
}

- (void)viewDidAppear:(BOOL)animated {
    
    [super viewDidAppear:animated];
    [self.sunnyRefreshControl startRefreshing];
}

# pragma mark - YALSunyRefreshControl methods

-(void)setupRefreshControl{
    
    self.sunnyRefreshControl = [YALSunnyRefreshControl attachToScrollView:self.tableView
                                                                   target:self
                                                            refreshAction:@selector(sunnyControlDidStartAnimation)];
}

-(void)sunnyControlDidStartAnimation{
    
    // start loading something
}


@end
