//
//  CityTableViewController.m
//  爱都市
//
//  Created by 杨晨曦 on 16/1/14.
//  Copyright © 2016年 杨晨曦. All rights reserved.
//

#import "CityTableViewController.h"
#import "SearchViewController.h"
@interface CityTableViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic, strong) NSMutableArray * dataArray;
@end

@implementation CityTableViewController



- (void)viewDidLoad {
    [super viewDidLoad];
    self.dataArray = [NSMutableArray array];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    NSUserDefaults * userDefaults = [NSUserDefaults standardUserDefaults];
    NSArray * arr =[userDefaults objectForKey:@"city"];
    self.dataArray = [NSMutableArray arrayWithArray:arr];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)addButtonClicked:(UIButton *)sender {
    
    SearchViewController * searchVC = [self.storyboard instantiateViewControllerWithIdentifier:@"SearchViewController"];
    searchVC.refreshLabelOfSuperView = ^(NSString *city){
        NSLog(@"%@",city);
        [self.dataArray addObject:city];
        [self.tableView reloadData];
        NSUserDefaults * userDefaults = [NSUserDefaults standardUserDefaults];
        [userDefaults setObject:self.dataArray forKey:@"city"];
        [userDefaults synchronize];
    };
    [self presentViewController:searchVC animated:YES completion:nil];
    
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"CELL"];
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"CELL"];
    }
    cell.textLabel.text = self.dataArray[indexPath.row];
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if(self.refreshLabelOfSuperView){
        self.refreshLabelOfSuperView(self.dataArray[indexPath.row]);
    }
    
    [self dismissViewControllerAnimated:YES completion:nil];
}
@end
