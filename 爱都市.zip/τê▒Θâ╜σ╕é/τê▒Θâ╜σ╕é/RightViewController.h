//
//  RightViewController.h
//  爱都市
//
//  Created by 杨晨曦 on 16/1/14.
//  Copyright © 2016年 杨晨曦. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Model.h"
@interface RightViewController : UIViewController
@property (nonatomic,copy)NSString * city;

@end
