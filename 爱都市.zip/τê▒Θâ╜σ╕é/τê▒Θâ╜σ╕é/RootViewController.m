//
//  RootViewController.m
//  爱都市
//
//  Created by 杨晨曦 on 16/1/14.
//  Copyright © 2016年 杨晨曦. All rights reserved.
//

#import "RootViewController.h"
#import "LeftViewController.h"
#import "MainViewController.h"
#import "RightViewController.h"
#import "weatherModel.h"
#import "Model.h"
@interface RootViewController (){
   
}

@end

@implementation RootViewController




-(void)awakeFromNib{
    
    //设置 sideMenu属性
//    self.scaleContentView = NO;
//    self.scaleMenuView = NO;
    
self.city = @"shanghai";
    self.contentViewInPortraitOffsetCenterX = 50;
    self.contentViewShadowEnabled = YES;
    self.contentViewShadowOffset = CGSizeMake(-10,10);
    self.contentViewShadowColor = [UIColor blackColor];
    self.contentViewShadowRadius = 5;
    //    1.添加左边和中间VC
    UIStoryboard * mainSb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    LeftViewController * leftVC = [mainSb instantiateViewControllerWithIdentifier:@"LeftViewController"];
    MainViewController * mainVC = [mainSb instantiateViewControllerWithIdentifier:@"MainViewController"];
    RightViewController * rightVC = [mainSb instantiateViewControllerWithIdentifier:@"RightViewController"];
    
    self.leftMenuViewController = leftVC;
    leftVC.city = self.city;
    self.rightMenuViewController = rightVC;
    rightVC.city = self.city;
    self.contentViewController = mainVC;
    mainVC.city = self.city;
    
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.navigationBarHidden = NO;
    self.navigationController.navigationBar.translucent = NO;
   
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
