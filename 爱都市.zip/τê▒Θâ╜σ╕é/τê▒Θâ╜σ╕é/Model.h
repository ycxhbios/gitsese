//
//  Model.h
//  weatherDemo
//
//  Created by 杨晨曦 on 16/1/7.
//  Copyright © 2016年 杨晨曦. All rights reserved.
//

#import <Foundation/Foundation.h>

@class Basic,Update,Now,Wind,Cond,Aqi,City,Suggestion,Drsg,Flu,Sport,Comf,Trav,Cw,Uv,Daily_Forecast,Cond1,Wind1,Tmp,Astro,Hourly_Forecast,Wind2;
@interface Model : JSONModel

@property (nonatomic, strong) NSArray<Hourly_Forecast *> *hourly_forecast;

@property (nonatomic, copy) NSString *status;

@property (nonatomic, strong) NSArray<Daily_Forecast *> *daily_forecast;

@property (nonatomic, strong) Now *now;

@property (nonatomic, strong) Aqi *aqi;

@property (nonatomic, strong) Basic *basic;

@property (nonatomic, strong) Suggestion *suggestion;

@end

@interface Basic : JSONModel

@property (nonatomic, copy) NSString *cnty;

@property (nonatomic, copy) NSString *CD;

@property (nonatomic, copy) NSString *lat;

@property (nonatomic, copy) NSString *city;

@property (nonatomic, copy) NSString *lon;

@property (nonatomic, strong) Update *update;

@end

@interface Update : JSONModel

@property (nonatomic, copy) NSString *loc;

@property (nonatomic, copy) NSString *utc;

@end

@interface Now : JSONModel

@property (nonatomic, copy) NSString *pres;

@property (nonatomic, copy) NSString *tmp;

@property (nonatomic, strong) Wind *wind;

@property (nonatomic, copy) NSString *hum;

@property (nonatomic, copy) NSString *vis;

@property (nonatomic, strong) Cond *cond;

@property (nonatomic, copy) NSString *fl;

@property (nonatomic, copy) NSString *pcpn;

@end

@interface Wind : JSONModel

@property (nonatomic, copy) NSString *dir;

@property (nonatomic, copy) NSString *deg;

@property (nonatomic, copy) NSString *sc;

@property (nonatomic, copy) NSString *spd;

@end

@interface Cond : JSONModel

@property (nonatomic, copy) NSString *txt;

@property (nonatomic, copy) NSString *code;

@end

@interface Aqi : JSONModel

@property (nonatomic, strong) City *city;

@end

@interface City : JSONModel

@property (nonatomic, copy) NSString *qlty;

@property (nonatomic, copy) NSString *pm25;

@property (nonatomic, copy) NSString *aqi;

@property (nonatomic, copy) NSString *co;

@property (nonatomic, copy) NSString *no2;

@property (nonatomic, copy) NSString *o3;

@property (nonatomic, copy) NSString *pm10;

@property (nonatomic, copy) NSString *so2;

@end

@interface Suggestion : JSONModel

@property (nonatomic, strong) Drsg *drsg;

@property (nonatomic, strong) Flu *flu;

@property (nonatomic, strong) Sport *sport;

@property (nonatomic, strong) Comf *comf;

@property (nonatomic, strong) Trav *trav;

@property (nonatomic, strong) Cw *cw;

@property (nonatomic, strong) Uv *uv;

@end

@interface Drsg : JSONModel

@property (nonatomic, copy) NSString *brf;

@property (nonatomic, copy) NSString *txt;

@end

@interface Flu : JSONModel

@property (nonatomic, copy) NSString *brf;

@property (nonatomic, copy) NSString *txt;

@end

@interface Sport : JSONModel

@property (nonatomic, copy) NSString *brf;

@property (nonatomic, copy) NSString *txt;

@end

@interface Comf : JSONModel

@property (nonatomic, copy) NSString *brf;

@property (nonatomic, copy) NSString *txt;

@end

@interface Trav : JSONModel

@property (nonatomic, copy) NSString *brf;

@property (nonatomic, copy) NSString *txt;

@end

@interface Cw : JSONModel

@property (nonatomic, copy) NSString *brf;

@property (nonatomic, copy) NSString *txt;

@end

@interface Uv : JSONModel

@property (nonatomic, copy) NSString *brf;

@property (nonatomic, copy) NSString *txt;

@end

@interface Daily_Forecast : JSONModel

@property (nonatomic, strong) Astro *astro;

@property (nonatomic, copy) NSString *pres;

@property (nonatomic, strong) Tmp *tmp;

@property (nonatomic, strong) Wind *wind;

@property (nonatomic, copy) NSString *hum;

@property (nonatomic, copy) NSString *date;

@property (nonatomic, copy) NSString *vis;

@property (nonatomic, strong) Cond *cond;

@property (nonatomic, copy) NSString *pcpn;

@property (nonatomic, copy) NSString *pop;

@end

@interface Cond1 : JSONModel

@property (nonatomic, copy) NSString *txt_d;

@property (nonatomic, copy) NSString *code_n;

@property (nonatomic, copy) NSString *code_d;

@property (nonatomic, copy) NSString *txt_n;

@end

@interface Wind1: JSONModel

@property (nonatomic, copy) NSString *dir;

@property (nonatomic, copy) NSString *deg;

@property (nonatomic, copy) NSString *sc;

@property (nonatomic, copy) NSString *spd;

@end

@interface Tmp : JSONModel

@property (nonatomic, copy) NSString *max;

@property (nonatomic, copy) NSString *min;

@end

@interface Astro : JSONModel

@property (nonatomic, copy) NSString *ss;

@property (nonatomic, copy) NSString *sr;

@end

@interface Hourly_Forecast : JSONModel

@property (nonatomic, copy) NSString *pres;

@property (nonatomic, strong) Wind *wind;

@property (nonatomic, copy) NSString *hum;

@property (nonatomic, copy) NSString *tmp;

@property (nonatomic, copy) NSString *pop;

@property (nonatomic, copy) NSString *date;

@end

@interface Wind2 : JSONModel

@property (nonatomic, copy) NSString *dir;

@property (nonatomic, copy) NSString *deg;

@property (nonatomic, copy) NSString *sc;

@property (nonatomic, copy) NSString *spd;

@end

