//
//  MainViewController.m
//  爱都市
//
//  Created by 杨晨曦 on 16/1/14.
//  Copyright © 2016年 杨晨曦. All rights reserved.
//

#import "MainViewController.h"
#import "weatherModel.h"
#import "MulticolorView.h"
#import <AFNetworking.h>
#import <UIImageView+AFNetworking.h>
#import <SVProgressHUD.h>
#import <KVNProgress.h>
#import "CityTableViewController.h"

@interface MainViewController ()
@property (weak, nonatomic) IBOutlet UILabel *titleLB;
@property (weak, nonatomic) IBOutlet UILabel *weatherNoLB;
@property (weak, nonatomic) IBOutlet UILabel *pm25LB;
@property (weak, nonatomic) IBOutlet UILabel *weatherTypeLB;
@property (nonatomic, strong) NSTimer         *timer;
@property (nonatomic, strong) MulticolorView  *showView;
@property (weak, nonatomic) IBOutlet UIImageView *backImageView;


@end

@implementation MainViewController

-(void)viewWillAppear:(BOOL)animated{


    

}
+(void)initialize{
    [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeClear];
    [SVProgressHUD setBackgroundColor:[UIColor colorWithRed:0 green:0 blue:0 alpha:0.6]];
    [SVProgressHUD setForegroundColor:[UIColor whiteColor]];
    [SVProgressHUD setRingThickness:10];
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.weatherTypeLB.layer.cornerRadius = 20;
    NSString *httpUrl = [NSString stringWithFormat:@"https://api.heweather.com/x3/weather?city=%@&key=cd90cdd6a5684cacaa16a87ce46f7097",self.city ];
//    NSString *httpUrl = [NSString stringWithFormat:@"https://api.heweather.com/x3/condition?search=allcond&key=cd90cdd6a5684cacaa16a87ce46f7097" ];
    [self request:httpUrl];
    self.navigationController.navigationBar.hidden = YES;

}
-(void)createCircle:(NSArray *)colors{
    
    _showView           = [[MulticolorView alloc] initWithFrame:CGRectMake(0, 0, 250, 250)];
    _showView.lineWidth = 15.f;
    _showView.sec       = 2.f;
    
    _showView.colors    = colors;
    _showView.center    = self.view.center;
    _timer              = [NSTimer scheduledTimerWithTimeInterval:100000
                                                           target:self
                                                         selector:@selector(event:)
                                                         userInfo:nil
                                                          repeats:YES];
    
    [self.view addSubview:_showView];
    [_showView startAnimation];
    
}
- (void)event:(id)object
{
    _showView.percent = arc4random()%100/100.f;
}

-(void)request: (NSString*)httpUrl {
    [SVProgressHUD showWithStatus:@"正在加载..."];
    
    AFHTTPSessionManager *mgr = [AFHTTPSessionManager manager];
    [mgr GET:httpUrl parameters:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
        [SVProgressHUD dismiss];
        NSArray *arr = responseObject[@"HeWeather data service 3.0"];

        for (NSDictionary * dict in arr) {

            Model * model = [[Model alloc]initWithDictionary:dict error:nil];
            dispatch_async(dispatch_get_main_queue(), ^{
                NSLog(@"%@",model.now.cond.txt);
                self.titleLB.text =model.basic.city;
                self.weatherNoLB.text = model.aqi.city.aqi;
                self.weatherTypeLB.text = model.aqi.city.qlty;
                self.pm25LB.text =model.aqi.city.pm25;
                NSArray * littleColor = @[(id)[UIColor blueColor].CGColor,
                                          (id)[UIColor whiteColor].CGColor,
                                          (id)[UIColor yellowColor].CGColor];
                NSArray * middleColor = @[(id)[UIColor greenColor].CGColor,
                                          (id)[UIColor redColor].CGColor,
                                          (id)[UIColor grayColor].CGColor];
                NSArray * bigColor = @[(id)[UIColor purpleColor].CGColor,
                                       (id)[UIColor redColor].CGColor,
                                       (id)[UIColor cyanColor].CGColor];
                if ([model.aqi.city.aqi intValue] <50) {
                    [self createCircle:littleColor];
                }
                if ([model.aqi.city.aqi intValue] >50 &&[model.aqi.city.aqi intValue] < 100) {
                    [self createCircle:middleColor];
                }
                if ([model.aqi.city.aqi intValue] >100) {
                    [self createCircle:bigColor];
                }
                if ([model.now.cond.txt isEqualToString:@"晴"]) {
                    self.backImageView.image = [UIImage imageNamed:@"3c239df0c5c65e5726d8bf413d8581ff"];

                }
                if ([model.now.cond.txt isEqualToString:@"霾"]) {
                    self.backImageView.image = [UIImage imageNamed:@"113022dwxo9z5zbx76fa2x-1"];

                }
                if ([model.now.cond.txt isEqualToString:@"阴"]) {
                    self.backImageView.image = [UIImage imageNamed:@"113022dwxo9z5zbx76fa2x-1"];
                }
                if ([model.now.cond.txt isEqualToString:@"小雨"]) {
                    self.backImageView.image = [UIImage imageNamed:@"d3ac238aced6dbb9s"];
                    
                }
                if ([model.now.cond.txt isEqualToString:@"中雨"]) {
                    self.backImageView.image = [UIImage imageNamed:@"d3ac238aced6dbb9s"];

                    
                }if ([model.now.cond.txt isEqualToString:@"阵雨"]) {
                    self.backImageView.image = [UIImage imageNamed:@"d3ac238aced6dbb9s"];
                    
                    
                }
                if ([model.now.cond.txt isEqualToString:@"大雨"]) {
                    self.backImageView.image = [UIImage imageNamed:@"d3ac238aced6dbb9s"];

                }
                if ([model.now.cond.txt isEqualToString:@"暴雨"]) {
                    self.backImageView.image = [UIImage imageNamed:@"d3ac238aced6dbb9s"];

                }
                if ([model.now.cond.txt isEqualToString:@"小雪"]) {
                    self.backImageView.image = [UIImage imageNamed:@"680a4be9hd15862abf8ce&690"];
                    
                }
                if ([model.now.cond.txt isEqualToString:@"中雪"]) {
                    self.backImageView.image = [UIImage imageNamed:@"680a4be9hd15862abf8ce&690"];
                }
                if ([model.now.cond.txt isEqualToString:@"大雪"]) {
                    self.backImageView.image = [UIImage imageNamed:@"680a4be9hd15862abf8ce&690"];
                }
                if ([model.now.cond.txt isEqualToString:@"多云"]) {
                    self.backImageView.image = [UIImage imageNamed:@"113022dwxo9z5zbx76fa2x-1"];

                }
            });
        }

     } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
         [SVProgressHUD showErrorWithStatus:[error localizedDescription]];

     }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

- (IBAction)leftButtonPressed:(UIButton *)sender {
}
- (IBAction)rightButtonPressed:(UIButton *)sender {
    CityTableViewController * cityVC = [self.storyboard instantiateViewControllerWithIdentifier:@"CityTableViewController"];
    cityVC.refreshLabelOfSuperView = ^(NSString *city){
        
        
        NSString * str = [self firstCharactor:city];
        NSCharacterSet * set = [NSCharacterSet characterSetWithCharactersInString:@" "];
        NSArray * array = [str componentsSeparatedByCharactersInSet:set];
        NSString * str1 = [array componentsJoinedByString:NULL];
        NSLog(@"%@",str1);
        if ([str1 isEqualToString:@"chengdou"]) {
            str1 =@"chengdu";
        }
        self.city = str1;
        
        NSString *httpUrl = [NSString stringWithFormat:@"https://api.heweather.com/x3/weather?city=%@&key=cd90cdd6a5684cacaa16a87ce46f7097",self.city ];
        [self request: httpUrl ];
        
        
    };
    [self presentViewController:cityVC animated:YES completion:nil];
    
}
- (NSString *)firstCharactor:(NSString *)aString
{
    //转成了可变字符串
    NSMutableString *str = [NSMutableString stringWithString:aString];
    //先转换为带声调的拼音
    CFStringTransform((CFMutableStringRef)str,NULL, kCFStringTransformMandarinLatin,NO);
    //再转换为不带声调的拼音
    CFStringTransform((CFMutableStringRef)str,NULL, kCFStringTransformStripDiacritics,NO);
    //    //转化为大写拼音
    //    NSString *pinYin = [str capitalizedString];
    //获取并返回首字母
    return str;
}

@end