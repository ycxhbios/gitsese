//
//  Model.m
//  weatherDemo
//
//  Created by 杨晨曦 on 16/1/7.
//  Copyright © 2016年 杨晨曦. All rights reserved.
//

#import "Model.h"

@implementation Model


+ (NSDictionary *)objectClassInArray{
    return @{@"daily_forecast" : [Daily_Forecast class], @"hourly_forecast" : [Hourly_Forecast class]};
}
@end
@implementation Basic
+(JSONKeyMapper *)keyMapper{
    
    JSONKeyMapper * mapper = [[JSONKeyMapper alloc]initWithJSONToModelBlock:^NSString *(NSString *keyName) {
        if ([keyName isEqualToString:@"id"]) {
            return @"CD";
        }else{
            
            return keyName;
        }
    } modelToJSONBlock:^NSString *(NSString *keyName) {
        if ([keyName isEqualToString:@"CD"]) {
            return @"id";
        }else{
            return keyName;
        }
    }];
    return mapper;
    
}
@end




@implementation Update

@end


@implementation Now

@end


@implementation Wind

@end


@implementation Cond

@end


@implementation Aqi

@end


@implementation City

@end


@implementation Suggestion

@end


@implementation Drsg

@end


@implementation Flu

@end


@implementation Sport

@end


@implementation Comf

@end


@implementation Trav

@end


@implementation Cw

@end


@implementation Uv

@end


@implementation Daily_Forecast

@end


@implementation Cond1

@end


@implementation Wind1

@end


@implementation Tmp

@end


@implementation Astro

@end


@implementation Hourly_Forecast

@end


@implementation Wind2

@end


