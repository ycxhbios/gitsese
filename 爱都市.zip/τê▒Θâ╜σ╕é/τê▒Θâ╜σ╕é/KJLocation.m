//
//  KJLocation.m
//  1228-AreaPicker
//
//  Created by kouhanjin on 15/12/28.
//  Copyright © 2015年 khj. All rights reserved.
//

#import "KJLocation.h"

@implementation KJLocation
@synthesize country = _country;
@synthesize state = _state;
@synthesize city = _city;
@synthesize street = _street;
@synthesize district = _district;
@synthesize latitude = _latitude;
@synthesize longitude = _longitude;
@end
