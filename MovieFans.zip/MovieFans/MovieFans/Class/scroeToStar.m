//
//  scroeToStar.m
//  MovieFans
//
//  Created by 晨曦 on 16/1/12.
//  Copyright © 2016年 joker. All rights reserved.
//

#import "scroeToStar.h"

@implementation scroeToStar

+ (float)scroeToStarWith:(NSString *)scroe{
    float a = [scroe floatValue];
    if (a >= 9.5) {
        return 5;
    }
    else if (a >= 8.5 & a < 9.5){
        return 4.5;
    }
    else if (a >= 7.5 & a < 8.5){
        return 4;
    }
    else if (a >= 6.5 & a < 7.5){
        return 3.5;
    }
    else if (a >= 5.5 & a < 6.5){
        return 3;
    }
    else if (a >= 4.5 & a < 5.5){
        return 2.5;
    }
    else if (a >= 3.5 & a < 4.5){
        return 2;
    }
    else if (a >= 2.5 & a < 3.5){
        return 1.5;
    }
    else if (a >= 1.5 & a < 2.5){
        return 1;
    }
    else{
        return 0.5;
    }
}

@end
