//
//  scroeToStar.h
//  MovieFans
//
//  Created by 晨曦 on 16/1/12.
//  Copyright © 2016年 joker. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface scroeToStar : NSObject

+ (float)scroeToStarWith:(NSString *)scroe;

@end
