//
//  Tool.h
//  1505BmobDemo
//
//  Created by HeHui on 16/1/7.
//  Copyright (c) 2016年 Hawie. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Tool : NSObject

+ (NSString *)MD5StringFromString:(NSString *)str;


@end
