//
//  CollectionCell.m
//  LimitFreeDemo
//
//  Created by Chaosky on 15/12/21.
//  Copyright © 2015年 1000phone. All rights reserved.
//

#import "CollectionCell.h"

@implementation CollectionCell

- (void)awakeFromNib {
    // Initialization code
}
@end
