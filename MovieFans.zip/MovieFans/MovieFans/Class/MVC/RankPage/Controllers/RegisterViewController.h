//
//  RegisterViewController.h
//  MovieFans
//
//  Created by 晨曦 on 16/2/12.
//  Copyright © 2016年 joker. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseDetailViewController.h"

@interface RegisterViewController : BaseDetailViewController

@end
