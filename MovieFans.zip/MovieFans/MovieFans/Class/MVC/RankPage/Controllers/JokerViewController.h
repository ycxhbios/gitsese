//
//  JokerViewController.h
//  MovieFans
//
//  Created by 晨曦 on 16/2/13.
//  Copyright © 2016年 joker. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseDetailViewController.h"

@interface JokerViewController : BaseDetailViewController

@end
