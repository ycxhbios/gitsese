//
//  CreatorInfoViewController.h
//  MovieFans
//
//  Created by 钟义 on 16/1/14.
//  Copyright © 2016年 joker. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CreatorInfoViewController : UIViewController

@property (nonatomic, strong) NSString *creatorID;


@end
