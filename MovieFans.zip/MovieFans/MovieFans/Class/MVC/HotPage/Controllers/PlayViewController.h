//
//  PlayViewController.h
//  CD1505VideoDemo
//
//  Created by HeHui on 16/1/14.
//  Copyright (c) 2016年 Hawie. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PlayViewController : UIViewController

@property (nonatomic, strong)NSString *movieUrl;

@end
