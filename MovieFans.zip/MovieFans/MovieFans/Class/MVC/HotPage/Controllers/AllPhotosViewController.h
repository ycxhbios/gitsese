//
//  AllPhotosViewController.h
//  MovieFans
//
//  Created by 晨曦 on 16/1/18.
//  Copyright © 2016年 joker. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AllPhotosViewController : UIViewController

@property (nonatomic, strong) NSMutableArray * dataArray;

@end
