//
//  RelationMovieCell.h
//  MovieFans
//
//  Created by 晨曦 on 16/1/14.
//  Copyright © 2016年 joker. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RelationInfoModel.h"

@protocol ClickRelationInfoCellDelegate <NSObject>

-(void)choseRelationInfoTerm:(NSInteger)num andPageID:(NSString *)pageid andCellNumber:(NSInteger)cellNumber;

@end

@interface RelationMovieCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *numberOfMovieLabel;
@property (weak, nonatomic) IBOutlet UIScrollView *relationMovieScrollView;
@property (weak, nonatomic) IBOutlet UIView *cubeView;
@property (weak, nonatomic) IBOutlet UIView *gestrueView;

@property (nonatomic, copy) NSString *title;
@property (nonatomic, strong) NSMutableArray *relationMovieArr;
@property (nonatomic, assign) BOOL isRandomColor;
@property (nonatomic, copy) NSString *numbers;
@property (nonatomic, copy) NSString * detailId;
@property (nonatomic, assign) NSInteger cellNumber;

@property (assign, nonatomic) id<ClickRelationInfoCellDelegate> delegate;


@end
