//
//  HotCell.m
//  MovieFans
//
//  Created by 晨曦 on 16/1/7.
//  Copyright © 2016年 joker. All rights reserved.
//

#import "HotCell.h"
#import "UIImageView+WebCache.h"

@implementation HotCell

- (void)awakeFromNib {
    self.scroeLabel.highlightedTextColor = [UIColor whiteColor];

    // Initialization code
    self.imageView.clipsToBounds = YES;
    //self.imageView.autoresizingMask = UIViewAutoresizingFlexibleHeight;
    //[self.imageView sizeToFit];
    //图片contentModel


//- (void)layoutSubviews {
//    [super layoutSubviews];
//    
//    for (UIView *subview in self.contentView.superview.subviews) {
//        if ([NSStringFromClass(subview.class) hasSuffix:@"SeparatorView"]) {
//            subview.hidden = NO;
//        }
//    }

}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


- (void)setModel:(HotModel *)model{
    
    _model = model;
   [self.imageView sd_setImageWithURL:[NSURL URLWithString:model.poster_url]placeholderImage:[UIImage imageNamed:@"weibo movie_yingping_pic_placeholder"]];
    self.commentImageView.image = [UIImage imageNamed:@"home_comment"];
    self.scroeLabel.text = model.score;
    self.nameLabel.text = model.name;
    if (model.score_count < 10000) {
        self.scroeCountLabel.text = [NSString stringWithFormat:@"%ld人点评",model.score_count];
    }else{
        long scoreCount = model.score_count / 10000;
        self.scroeCountLabel.text = [NSString stringWithFormat:@"%ld万人点评",scoreCount];
    }
    

}

- (void)scrollImageInTableview:(UITableView *)tableView inView:(UIView *)view{
    
    //1.获取当前cell在vc.view中的相对frame
    CGRect inSuperViewRect = [tableView convertRect:self.frame toView:view];
    //2.获取当前cell的起始 y 离vc.view的中线的距离
    CGFloat disFromCenterY = CGRectGetMidY(view.frame) - CGRectGetMinY(inSuperViewRect);
    //3.获取ImageView的高度和cell高度的差值
    CGFloat diff = CGRectGetHeight(self.imageView.frame) - CGRectGetHeight(self.frame);
    //4.获取移动多少像素 用cell离中线y距离和整个vc.view的高度之比 乘以图片和cell的高度差
    CGFloat moveDis = disFromCenterY / CGRectGetHeight(view.frame) * diff;
    //5.让图片的frame移动距离 --moveDis
    CGRect scrollRect = self.imageView.frame;
    scrollRect.origin.y = - (diff/2.0) + moveDis;
    self.imageView.frame = scrollRect;
}


@end
