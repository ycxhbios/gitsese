//
//  HotCell.h
//  MovieFans
//
//  Created by 晨曦 on 16/1/7.
//  Copyright © 2016年 joker. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HotModel.h"

@interface HotCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UIView *gradientView;
@property (weak, nonatomic) IBOutlet UILabel *scroeLabel;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UIImageView *commentImageView;
@property (weak, nonatomic) IBOutlet UILabel *scroeCountLabel;

@property (nonatomic, strong) CAGradientLayer * gradientLayer;

@property (nonatomic, strong) HotModel *model;

- (void)scrollImageInTableview:(UITableView *)tableView inView:(UIView *)view;

@end
