//
//  IntroduceTableViewCell.m
//  MovieFans
//
//  Created by 晨曦 on 16/1/13.
//  Copyright © 2016年 joker. All rights reserved.
//

#import "IntroduceTableViewCell.h"


@implementation IntroduceTableViewCell



- (void)awakeFromNib {
    // Initialization code
}

//-(void)setModel:(BaseInfoModel *)model{
//    _model = model;
//    self.IntroduceLabel.text = _model.desc;
//}

- (void)setIntroduceText:(NSString *)introduceText{
    _introduceText = introduceText;
    self.IntroduceLabel.text = _introduceText;
}


//- (void)setDesc:(NSString *)desc{
//    self.IntroduceLabel.text = desc;
//}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
