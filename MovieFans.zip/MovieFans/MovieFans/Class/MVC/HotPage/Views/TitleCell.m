//
//  TitleCell.m
//  MovieFans
//
//  Created by 晨曦 on 16/1/19.
//  Copyright © 2016年 joker. All rights reserved.
//

#import "TitleCell.h"

@implementation TitleCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)setTitle:(NSString *)title{
    _title = title;
}

- (void)setNumber:(NSString *)number{
    _number = number;
}

- (void)layoutSubviews{
    _titleLabel.text = _title;
    _numberLabel.text = [NSString stringWithFormat:@"查看全部%@",_number];
}

@end
