//
//  ReviewInfoModel.m
//  MovieFans
//
//  Created by 晨曦 on 16/1/12.
//  Copyright © 2016年 joker. All rights reserved.
//

#import "ReviewInfoModel.h"
#import "PicUrlsModel.h"


@implementation ReviewInfoModel

//+ (NSDictionary *)mj_objectClassInArray
//{
//    return @{@"large_pics":@"PicUrlsModel"};
//}

@end

@implementation Share_Info

+ (NSDictionary *)objectClassInArray{
    return @{@"share_pic" : [Share_Pic class]};
}



@end


@implementation Share_Pic

@end


@implementation User

@end


