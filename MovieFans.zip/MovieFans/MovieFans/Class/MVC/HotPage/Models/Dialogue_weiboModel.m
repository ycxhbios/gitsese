//
//  Dialogue_weiboModel.m
//  MovieFans
//
//  Created by 晨曦 on 16/1/12.
//  Copyright © 2016年 joker. All rights reserved.
//

#import "Dialogue_weiboModel.h"


@implementation Dialogue_weiboModel

@end
