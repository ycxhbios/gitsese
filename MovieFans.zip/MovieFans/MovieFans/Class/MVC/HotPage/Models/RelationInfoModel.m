//
//  RelationInfoModel.m
//  MovieFans
//
//  Created by 晨曦 on 16/1/12.
//  Copyright © 2016年 joker. All rights reserved.
//

#import "RelationInfoModel.h"


@implementation RelationInfoModel


+ (NSDictionary *)objectClassInArray{
    return @{@"directors" : [Directors class]};
}
@end
@implementation Directors

@end


