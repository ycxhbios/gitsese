//
//  CollectionTableModel.h
//  MovieFans
//
//  Created by 晨曦 on 16/2/13.
//  Copyright © 2016年 joker. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CollectionTableModel : NSObject

@property (nonatomic, copy) NSString * appId;
@property (nonatomic, copy) NSString * appName;
@property (nonatomic, copy) NSString * appImage;

@end
