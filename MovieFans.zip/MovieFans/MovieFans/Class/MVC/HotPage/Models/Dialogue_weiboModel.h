//
//  Dialogue_weiboModel.h
//  MovieFans
//
//  Created by 晨曦 on 16/1/12.
//  Copyright © 2016年 joker. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BaseModel.h"
#import <MJExtension.h>
@interface Dialogue_weiboModel : BaseModel

@end
