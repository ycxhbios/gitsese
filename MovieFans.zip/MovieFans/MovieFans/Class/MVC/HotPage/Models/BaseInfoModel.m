//
//  BaseInfoModel.m
//  MovieFans
//
//  Created by 晨曦 on 16/1/12.
//  Copyright © 2016年 joker. All rights reserved.
//

#import "BaseInfoModel.h"


@implementation BaseInfoModel

@end
@implementation Feature_Videos

@end


@implementation Videos

+ (NSDictionary *)objectClassInArray{
    return @{@"list" : [List class]};
}

@end


@implementation List

@end


