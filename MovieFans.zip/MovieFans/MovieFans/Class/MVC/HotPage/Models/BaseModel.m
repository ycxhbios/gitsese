
//
//  BaseModel.m
//  MovieFans
//
//  Created by 晨曦 on 16/1/7.
//  Copyright © 2016年 joker. All rights reserved.
//

#import "BaseModel.h"

@implementation BaseModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
    
}

@end
