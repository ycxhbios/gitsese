//
//  BaseModel.h
//  MovieFans
//
//  Created by 晨曦 on 16/1/7.
//  Copyright © 2016年 joker. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BaseModel : NSObject

@end
