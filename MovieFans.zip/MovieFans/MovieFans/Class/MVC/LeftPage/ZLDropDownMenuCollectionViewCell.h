//
//  ZLDropDownMenuCollectionViewCell.h
//  ZLDropDownMenuDemo
//
//  Created by zhaoliang on 16/1/27.
//  Copyright © 2016年 zhao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZLDropDownMenuCollectionViewCell : UICollectionViewCell

@property (nonatomic, copy) NSString *contentString;

@end
