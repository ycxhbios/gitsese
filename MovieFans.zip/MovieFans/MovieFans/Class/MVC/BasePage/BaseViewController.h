//
//  BaseViewController.h
//  MovieFans
//
//  Created by 晨曦 on 16/2/12.
//  Copyright © 2016年 joker. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseViewController : UIViewController

@end
