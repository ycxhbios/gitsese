//
//  ShortFrameModel.m
//  MovieFans
//
//  Created by 钟义 on 16/1/20.
//  Copyright © 2016年 joker. All rights reserved.
//

#import "ShortFrameModel.h"
#import "PicBackgroundView.h"

CGFloat const vWH = 15;

@implementation ShortFrameModel

- (void)setReviewModel:(ReviewInfoModel *)reviewModel{
    
    _reviewModel = reviewModel;
    NSDictionary * userDic = (id)reviewModel.user;
    NSString * userName = [userDic valueForKey:@"name"];
    
    /** 第一块*/
    /** 一、顶部背景图层*/
    CGFloat topBGX = 0;
    CGFloat topBGY = 0;
    CGFloat topBGW = SCREEN_WIDTH;
    CGFloat topBGH = 0; // 暂时设为0;
    
    
    /** 用户图像*/
    CGFloat userIconX = WB_SPACING_NORMAL;
    CGFloat userIconY = WB_SPACING_NORMAL;
    CGFloat userIconWH = 40;
    self.userIconImageViewFrame = CGRectMake(userIconX, userIconY, userIconWH, userIconWH);
    
    /** 用户名*/
    CGFloat userNameX = CGRectGetMaxX(self.userIconImageViewFrame) + WB_SPACING_NORMAL;
    CGFloat userNameY = userIconY;
    
    CGSize userNameSize = [userName sizeWithAttributes:@{NSFontAttributeName:WB_FONT_USERNAME}];
    self.userNameLabelFrame = (CGRect) {{userNameX,userNameY},userNameSize};
    
    /** 星星评分*/
    CGFloat startX = CGRectGetMinX(self.userNameLabelFrame);
    CGFloat startY = CGRectGetMaxY(self.userNameLabelFrame) + WB_SPACING_SMALL;
    CGFloat startW = 60;
    CGFloat startH = 15;
    self.startViewFrame = CGRectMake(startX, startY, startW, startH);
    
    /** 发布时间*/
    CGFloat wbCTimeX = SCREEN_WIDTH - 115;
    CGFloat wbCTimeY = CGRectGetMaxY(self.userNameLabelFrame) + WB_SPACING_SMALL;
    CGFloat wbCTimeW = 100;
    CGFloat wbCTimeH = 15;
    self.wbCreateTimeLabelFrame = CGRectMake(wbCTimeX, wbCTimeY, wbCTimeW, wbCTimeH);
    
    topBGH = CGRectGetMaxY(self.userIconImageViewFrame) + WB_SPACING_NORMAL;
    
    self.topBackgroundViewFrame = CGRectMake(topBGX, topBGY, topBGW, topBGH);
    
    
    /** 第二块*/
    /** 二、用户自己发布的微博内容背景图层*/
    CGFloat secondBGX = topBGX;
    CGFloat secondBGY = CGRectGetMaxY(self.topBackgroundViewFrame);
    CGFloat secondBGW = topBGW;
    CGFloat secondBGH = 0;
    
    /** 1.微博文字内容*/
    CGFloat wbContentX = userIconX;
    CGFloat wbContentY = 0;
    
    CGSize wbContentSize = [reviewModel.text boundingRectWithSize:CGSizeMake(secondBGW - 2*wbContentX, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:WB_FONT_USERNAME} context:nil].size;
    
    self.wbContentLableFrame = (CGRect){{wbContentX,wbContentY},wbContentSize};
    
    /** 2.微博图片内容的背景图层*/
    CGFloat wbPicBgX = 0;
    CGFloat wbPicBgY = CGRectGetMaxY(self.wbContentLableFrame);
    if (reviewModel.large_pics.count != 0) {
        wbPicBgY = CGRectGetMaxY(self.wbContentLableFrame) + WB_SPACING_NORMAL;
    }
    
    CGFloat wbPicBgW = secondBGW;
    CGFloat wbPicBgH = [PicBackgroundView heightWithNum:reviewModel.large_pics.count];
    
    self.wbPicsBackgroundViewFrame = CGRectMake(wbPicBgX, wbPicBgY, wbPicBgW, wbPicBgH);
    
    
    secondBGH = CGRectGetMaxY(self.wbPicsBackgroundViewFrame);
    
    self.secondBackgroundViewFrame = CGRectMake(secondBGX, secondBGY, secondBGW, secondBGH);

    
    /** 底部图层*/
    CGFloat bottomX = topBGX;
    CGFloat bottomY = CGRectGetMaxY(self.secondBackgroundViewFrame)+2;
    CGFloat bottomW = topBGW;
    CGFloat bottomH = 40;
    
    self.bottomBackgroundViewFrame = CGRectMake(bottomX, bottomY, bottomW, bottomH);
    
    self.titleimageViewFrame = CGRectMake(WB_SPACING_NORMAL, WB_SPACING_NORMAL, 20, 20);
    
    
    self.titleLabelFrame = CGRectMake(CGRectGetMaxX(self.titleimageViewFrame)+WB_SPACING_SMALL, WB_SPACING_NORMAL, 200, 20);
//    CGSize filmNameSize = [reviewModel.film_name sizeWithAttributes:@{NSFontAttributeName:WB_FONT_TIME}];
//    self.titleLabelFrame = (CGRect) {{CGRectGetMaxX(self.titleimageViewFrame)+WB_SPACING_SMALL,WB_SPACING_NORMAL},filmNameSize};
    
    self.promptLabelFrame = CGRectMake(bottomW-90, WB_SPACING_NORMAL+5, 90, 20);
    
    self.lineViewFrame = CGRectMake(0, 3, bottomW, 1);
    
    // 计算cell的高度
    self.cellHeight = CGRectGetMaxY(self.bottomBackgroundViewFrame) + WB_SPACING_SMALL;;
}

@end
