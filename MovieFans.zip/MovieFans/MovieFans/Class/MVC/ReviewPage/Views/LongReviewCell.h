//
//  LongReviewCell.h
//  MovieFans
//
//  Created by 晨曦 on 16/1/19.
//  Copyright © 2016年 joker. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ReviewInfoModel.h"

@interface LongReviewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIView *gradientView;
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

@property (weak, nonatomic) IBOutlet UILabel *filmNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *dateLabel;
@property (weak, nonatomic) IBOutlet UILabel *textLabel;
@property (weak, nonatomic) IBOutlet UIImageView *userIconImageView;
@property (weak, nonatomic) IBOutlet UILabel *userNameLabel;
@property (weak, nonatomic) IBOutlet UIView *startView;
@property (weak, nonatomic) IBOutlet UILabel *boolLabel;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *textLabelHeight;

@property (nonatomic, strong) CAGradientLayer * gradientLayer;
@property (nonatomic, strong) ReviewInfoModel * model;
@property (nonatomic, strong) NSString *string;
//@property (nonatomic, assign) BOOL isDetail;

@end
