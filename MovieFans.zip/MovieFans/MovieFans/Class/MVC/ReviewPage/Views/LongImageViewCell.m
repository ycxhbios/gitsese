//
//  LongImageViewCell.m
//  MovieFans
//
//  Created by 晨曦 on 16/1/20.
//  Copyright © 2016年 joker. All rights reserved.
//

#import "LongImageViewCell.h"
#import "UIImageView+WebCache.h"

@implementation LongImageViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)setPicUrlString:(NSString *)picUrlString{
    _picUrlString = picUrlString;
    [self.imageView sd_setImageWithURL:[NSURL URLWithString:_picUrlString]placeholderImage:[UIImage imageNamed:@"weibo movie_yingping_pic_placeholder"]];
    self.imageView.contentMode = UIViewContentModeScaleAspectFit;

    
}

- (void)layoutSubviews{
    self.imageView.contentMode = UIViewContentModeScaleAspectFit;

    
}

@end
