//
//  LongContentCell.m
//  MovieFans
//
//  Created by 晨曦 on 16/1/20.
//  Copyright © 2016年 joker. All rights reserved.
//

#import "LongContentCell.h"

@implementation LongContentCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)setContentText:(NSString *)contentText{
    _contentText = contentText;
    
    NSArray * colorArr = @[[UIColor greenColor],[UIColor redColor],[UIColor blueColor],[UIColor cyanColor],[UIColor brownColor],[UIColor orangeColor],[UIColor purpleColor],[UIColor magentaColor],[UIColor darkGrayColor]];
    
    NSRange range1={5,1};
//    NSString *stringFirst = [contentText substringWithRange:range1];
    NSMutableString * changeString = [[NSMutableString alloc]init];
    [changeString appendFormat:@"     %@",contentText];
    NSMutableAttributedString * mutableAttrString = [[NSMutableAttributedString alloc]initWithString:changeString];
    
    [mutableAttrString setAttributes:@{NSForegroundColorAttributeName:colorArr[arc4random()%9],NSFontAttributeName:[UIFont fontWithName:@"SentyMARUKO" size:30]} range:range1];
    //SentyMARUKO   MComic HK
    //    NSRange range2={1,contentText.length-1};
//    NSString * thenString = [contentText substringWithRange:range2];
//    NSMutableString * changeString = [[NSMutableString alloc]init];
//    [changeString appendFormat:@"       %@%@",attrString,thenString];
    
    _contentLabel.attributedText = mutableAttrString;
}

@end
