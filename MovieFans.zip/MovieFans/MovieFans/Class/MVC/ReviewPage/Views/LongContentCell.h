//
//  LongContentCell.h
//  MovieFans
//
//  Created by 晨曦 on 16/1/20.
//  Copyright © 2016年 joker. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LongContentCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *contentLabel;

@property (nonatomic, strong) NSString *contentText;

@end
