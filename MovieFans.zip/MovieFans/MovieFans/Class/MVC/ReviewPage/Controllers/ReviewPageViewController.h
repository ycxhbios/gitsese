//
//  ReviewPageViewController.h
//  movies
//
//  Created by 晨曦 on 16/1/7.
//  Copyright © 2016年 joker. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface ReviewPageViewController :BaseViewController

@end
