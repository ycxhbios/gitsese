//
//  LongReviewDetailViewController.h
//  MovieFans
//
//  Created by 晨曦 on 16/1/20.
//  Copyright © 2016年 joker. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LongReviewDetailViewController : UIViewController

@property (nonatomic, strong) NSString * ID;

@end
